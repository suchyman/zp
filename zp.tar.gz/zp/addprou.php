<?php
include './include/gora.php';

ini_set( 'display_errors', 'On' ); 
error_reporting( E_ALL );



 /*
 $sql = "INSERT INTO `markers` (id, name, address, lat, lng, type) VALUES (NULL, 1, 'Roweckiego', '$_GET[newlat]', '$_GET[newlng]', '$_GET[opis]')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

echo'poszlo!'; 
*/

/* idziemy z linka: http://192.168.0.152/prod/addprou.php?newlat=51.416036260974565&newlng=21.958398433776892&opis=testowo */


		$newlat = stripslashes($_REQUEST['newlat']); 
		$newlng = stripslashes($_REQUEST['newlng']); 
		/*$opis = stripslashes($_REQUEST['opis']);*/ 
		/*$iduser = stripslashes($_REQUEST['iduser']);*/ 
		
?>
<header class='masthead bg-primary text-white text-center'>
      <div class='container'>
        <h2 class='font-weight-light mb-0'>Dodawanie nowego zgłoszenia<br><br><br></h2>
<form action="add.php" method="POST" ENCTYPE="multipart/form-data">
Nazwa zgłoszenia: <input type="text" name="nazwa"><br>
Opis zgłoszenia: <input type="text" name="opis"><br>
<input type="file" name="userpic" id="userpic"><br/>
<input type="hidden" name="lat" value="<?php echo $newlat;?>"><br>
<input type="hidden" name="lng" value="<?php echo $newlng;?>"><br>
<button type="submit" name="button">Dodaj zgłoszenie</button>
</form>

<?php
include './include/stopka.php';
?>