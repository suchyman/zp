<?php
include './include/gora.php';
?>
    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <h1 class="text-uppercase mb-0">Dodaj zgłoszenie</h1>
        <hr class="star-light">
                <h2 class="font-weight-light mb-0">
                
Dodawanie nowych zgloszen
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'      
    'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>      
<html xmlns="http://www.w3.org/1999/xhtml">      
    <head>      
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />      
		<style type="text/css" media="all">@import "/style/Przyklad.css";</style>
        		
		
        <script src="https://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>    
			<script type="text/javascript">   

			var mapa; // obiekt globalny
			var dymek = new google.maps.InfoWindow();
			
			function mapaStart()  
			{  
				var wspolrzedne = new google.maps.LatLng(51.417428, 21.969771);
				var opcjeMapy = {
					zoom: 14,
					center: wspolrzedne,
					mapTypeId: google.maps.MapTypeId.ROADMAP,
					disableDefaultUI: false
				};
				mapa = new google.maps.Map(document.getElementById("mapka"), opcjeMapy); 			
								
				google.maps.event.addListener(mapa,'click',function(zdarzenie)
				{
					if(zdarzenie.latLng)	
					{
                    var linkvalue ='addprou.php?newlat=' + zdarzenie.latLng.lat()+'&newlng='+zdarzenie.latLng.lng();
					var link = '<a class="button" href ='+ linkvalue + '>Dodaj tu zdarzenie</a>';
					dymek.setContent(link);
					dymek.setPosition(zdarzenie.latLng);  
					dymek.open(mapa); 
					}
				});
				
				google.maps.eve
			}  
			
			function dodajMarker(wspolrzedne)
			{
				var marker = new google.maps.Marker({
					position: wspolrzedne,
					map: mapa
				});
				google.maps.event.addListener(marker,'click',function(zdarzenie)
				{
					dymek.setContent('To jest Twoje<br />Współrzędne GPS markera:<br />'+marker.getPosition());  
					dymek.setPosition(marker.getPosition());  
					dymek.open(mapa);
				});
			}
		
		</script>   
    </head>      
    <body onload="mapaStart()">    
      
	
		
		<div id="mapka" style="width: 100%; height: 200px; border: 1px solid black; background: gray;">   
		   
		</div>   
		<p id="info">
			<!-- menu -->
		</p>
    </body>      
</html>  
                
                
                </h2>
<?php
include './include/stopka.php';
?>