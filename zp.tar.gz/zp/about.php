<?php
include './include/gora.php';
?>

    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="https://www.pulawy.eu/img/wysiwig/images/logo_pol.jpg" alt="">
        <h1 class="text-uppercase mb-0">O projekcie</h1>
        <hr class="star-light">
        <h2 class="font-weight-light mb-0">System Zgłaszania Probemów Miejskich został wytworzony przez współpracy Centrum Usług Wspólnych w Puławach przy współpracy z Wydziałem Komunikacji Społecznej Urzędu Miasta Puławy. <br> hehehe </h2>
      </div>
    </header>
   

<?php
include './include/stopka.php';
?>