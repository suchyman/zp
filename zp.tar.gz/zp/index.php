<?php
include './include/gora.php';
?>
    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="img/profile.png" alt="">
        <h1 class="text-uppercase mb-0">Zgłoś problem!</h1>
        <hr class="star-light">
        <h2 class="font-weight-light mb-0">Problem - Zgłoś - Reakcja - Problem rozwiązany</h2>
      </div>
    </header>
   
<?php
include './include/stopka.php';
?>
