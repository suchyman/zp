<?php
include './include/gora.php';
?>
    <!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <img class="img-fluid mb-5 d-block mx-auto" src="https://news-cdn.softpedia.com/images/news2/You-Can-Edit-Google-Maps-via-Map-Maker-in-Canada-Now-2.png" alt="">
        <h1 class="text-uppercase mb-0">Logowanie</h1>
        <hr class="star-light">
        
<?php
include './include/stopka.php';
?>
