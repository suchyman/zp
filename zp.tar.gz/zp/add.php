<?php

include("../inc/conn.php");

ini_set( 'display_errors', 'On' ); 
error_reporting( E_ALL );

$newfilename = time() . '_' . rand(100,999) . '.' . end(explode(".",$_FILES["userpic"]["name"]));
move_uploaded_file($_FILES["userpic"]["tmp_name"], "img/" . $newfilename);

echo'Dziękujemy za zgłoszenie<br> Podsumowanie:<br>';

		$newlat = stripslashes($_REQUEST['lat']); 
		$newlng = stripslashes($_REQUEST['lng']); 
		$opis = stripslashes($_REQUEST['opis']); 
		
		echo 'Współrzędne punktu: ' . ($_POST["lat"]) . ' ';
		echo ($_POST["lng"]) . '<br>';
		echo 'Nazwa: ' . ($_POST["nazwa"]) . '<br>';		
		
		echo 'Opis zgłoszenia: ' . ($_POST["opis"]) . '<br>';
		
		echo '<img src=img/' . $newfilename . ' height = "30%">';
		
		
		$sql = "INSERT INTO `markers` (id, name, address, lat, lng, type, img) VALUES (NULL, 1, '$_POST[nazwa]', '$_POST[lat]', '$_POST[lng]', '$_POST[opis]', '$newfilename')";

if ($conn->query($sql) === TRUE) {
    echo "<br>Dodano nowe zgłoszenie!";
} else {
    echo "Błądzik: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>