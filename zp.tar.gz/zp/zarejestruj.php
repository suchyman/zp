<?php
include './include/gora.php';
?>

<?php
	include './include/conn.php';
    // If form submitted, insert values into the database.
    if (isset($_REQUEST['username'])){
		$username = stripslashes($_REQUEST['username']); // removes backslashes
		$username = mysqli_real_escape_string($conn,$username); //escapes special characters in a string
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($conn,$email);
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($conn,$password);

		$trn_date = date("Y-m-d H:i:s");
        $query = "INSERT into `users` (username, password, email, trn_date) VALUES ('$username', '".md5($password)."', '$email', '$trn_date')";
        $result = mysqli_query($conn,$query);
        if($result){
            echo "
<header class='masthead bg-primary text-white text-center'>
      <div class='container'>
        <h2 class='font-weight-light mb-0'>Rejestracja przebiegła pomyślnie<br><a href='login.php'>Można się zalogować</a><br><br></h2>
                 
            ";
        }
    }else{
?>
<!-- Header -->
    <header class="masthead bg-primary text-white text-center">
      <div class="container">
        <h1 class="text-uppercase mb-0">Rejestracja</h1>
        <h2 class="font-weight-light mb-0">Rejestracja przebiegła pomyślnie</h2>
        
        
<div class="form">
<form name="registration" action="" method="post">
<input type="text" name="username" placeholder="nazwa użytkownika" required />
<input type="email" name="email" placeholder="email" required />
<input type="password" name="password" placeholder="hasło" required />
<input type="submit" name="submit" value="Zarejestruj" />
</form></h2>
      </div>
    </header>

<?php } ?> 

<?php
include './include/stopka.php';
?>